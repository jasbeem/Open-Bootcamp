#!/usr/bin/python3
texto = "Hola mundo!"
print(texto)
